# Project Chronicle

An application that helps people increase knowledge retention.
It is being deployed through a Django Framework (Python), with an HTML/JS front-end. 

Team Members: Please install [Zenhub](https://www.zenhub.com/) to make project management easier on Github!

## How to Commit

Check out [CONTRIBUTING.md] (https://github.com/bhairavmehta95/Project-Chronicle/blob/master/CONTRIBUTING.md) to see how to contribute.


[Check the wiki for more task-specific details](https://github.com/bhairavmehta95/Project-Chronicle/wiki)
## Goals of the Application

```python
goals = pass 
#ComingSoon 
```

## Tools

* Google Cloud Speech API - Speech Recogntion
* Wikipedia - Sources for articles and automatic question generation
* Django - Framework for application

## How Do We Do It

```python
is_good_question = True
```
